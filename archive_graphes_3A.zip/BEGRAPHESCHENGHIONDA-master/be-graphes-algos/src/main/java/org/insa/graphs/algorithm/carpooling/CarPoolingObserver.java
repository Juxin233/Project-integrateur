package org.insa.graphs.algorithm.carpooling;

public interface CarPoolingObserver {

}
