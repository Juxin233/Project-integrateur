package org.insa.graphs.algorithm.carpooling;

public class CarPoolingTextObserver implements CarPoolingObserver {

}
