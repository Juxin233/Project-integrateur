package org.insa.graphs.algorithm.packageswitch;

public class PackageSwitchGraphicObserver implements PackageSwitchObserver {

}
