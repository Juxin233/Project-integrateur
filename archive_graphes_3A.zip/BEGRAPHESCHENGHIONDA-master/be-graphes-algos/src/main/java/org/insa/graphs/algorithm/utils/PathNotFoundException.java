package org.insa.graphs.algorithm.utils;

public class PathNotFoundException extends Exception{
    public PathNotFoundException(String motif){
        super(motif);
    } 
}
