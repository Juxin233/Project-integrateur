package org.insa.graphs.algorithm.utils;

public class EmptyPriorityQueueException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public EmptyPriorityQueueException() {
    }

}
