package org.insa.graphs.algorithm.packageswitch;

import org.insa.graphs.algorithm.AbstractSolution;

public class PackageSwitchSolution extends AbstractSolution {

    protected PackageSwitchSolution(PackageSwitchData data, Status status) {
        super(data, status);
    }

}
